public interface Updater_itf  {

	public void update();

}