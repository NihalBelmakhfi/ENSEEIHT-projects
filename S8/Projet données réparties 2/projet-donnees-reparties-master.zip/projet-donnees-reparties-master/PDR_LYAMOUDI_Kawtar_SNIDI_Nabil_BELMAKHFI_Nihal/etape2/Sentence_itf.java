
public interface Sentence_itf extends SharedObject_itf {
	public void write(String text);
	public String read();
}