public interface Updater_itf  {
	public void update (Client_itf client);

}