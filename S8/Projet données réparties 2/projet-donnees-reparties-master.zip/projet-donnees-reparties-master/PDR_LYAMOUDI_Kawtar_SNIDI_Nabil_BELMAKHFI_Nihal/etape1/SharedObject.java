import java.io.*;


public class SharedObject implements Serializable, SharedObject_itf {

    //Définition des attributs
    private static final long serialVersionUID = 1L;
    protected boolean accesPossible;
    protected Lock lock;
    // NL : no local lock Lock.NL
    // RLC : read lock cached (not taken) Lock.RLC 
    // WLC : write lock cached Lock.WLC
    // RLT : read lock taken Lock.RLT
    // WLT : write lock taken Lock.WLT 
    // RLT_WLC : read lock taken and write lock cached Lock.RLT_WLC
    private enum Lock{NL, RLC, WLC, RLT, WLT, RLT_WLC};
    protected Object obj;
    protected int id;

//=================================================//
//  Définition des setters and getters de la classe//
//=================================================//
    
    @Override
    public int getId() {
        return this.id;
    }
    @Override
    public Object getObjet() {
        return this.obj;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }
    @Override
    public void setObjet(Object objet) {
        this.obj = objet;
    }

//=================================================//
//  Le constructeur de la classe				   //
//=================================================//

    public SharedObject(Object o, int id) {
        super();
        this.accesPossible = false;
        this.obj = o;
        this.lock = Lock.NL;
        this.id = id;
    }

//============================================================//
//  Méthode lock_read: obtention d'un verrou en écriture	  //
//============================================================//

    // invoked by the user program on the client node
    @Override
    public void lock_read() {
        boolean modifier = false;
        synchronized (this) {
            while (this.accesPossible) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }        
            switch(lock) {
                case NL:
                    modifier = true;
                    lock = Lock.RLT;
                    break;
                case RLC:
                    lock = Lock.RLT;
                    break;
                case WLC:
                    lock = Lock.RLT_WLC;
                    break;
                default:
                    break;
            }
            if (modifier) {
                obj = Client.lock_read(id);
            }
        }
	}

//============================================================//
//  Méthode lock_write: obtention d'un verrou en écriture	  //
//============================================================//

	// invoked by the user program on the client node
    @Override
    public void lock_write() {
        boolean demander = false;
        synchronized (this) {
            while (this.accesPossible) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            switch (lock) {
                case NL:
                    demander = true;
                    lock = Lock.WLT;
                    break;
                case RLC:
                    demander = true;
                    lock = Lock.WLT;
                    break;
                case WLC:
                    lock = Lock.WLT;
                    break;
                default:
                    break;
            }
        } 
        if (demander) {
            obj = Client.lock_write(id);
        }
    }

//============================================================//
//  Méthode libérer le verrou après un lock_read ou lock_write//
//============================================================//

    // invoked by the user program on the client node
    @Override
    public synchronized void unlock() {
        switch(lock) {
            case RLT:
                lock = Lock.RLC;
                break;
            case WLT:
                lock = Lock.WLC;
                break;
            case RLT_WLC:
                lock = Lock.WLC;
                break;
            default:
                break;
        }
        try {
            notify();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//============================================================//
//  Méthode reduce_lock: passer du mode d'écriture en lecture //
//============================================================//

    // callback invoked remotely by the server
    public synchronized Object reduce_lock() {
        this.accesPossible = true;
        switch (lock) {
            case WLT:
            while (lock == Lock.WLT) {
                try{
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            case WLC:
                lock = Lock.RLC;
                break;
            case RLT_WLC:
                lock = Lock.RLT;
                break;
            default:
                break;
        }
        
        this.accesPossible = false;

        try {
            notify();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return obj;
    }

//============================================================//
//  Méthode invalidate_reader: invalider un lecteur			  //
//============================================================//

    // callback invoked remotely by the server
    public synchronized void invalidate_reader() {
        
        this.accesPossible = true;
        switch (lock) {
            case RLT:
                while (lock == Lock.RLT) {
                    try {
                        wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                
            case RLC:
                lock = Lock.NL;
                break;
            default:
                break;
        }

        this.accesPossible = false;
        try {
            notify();
        } catch (Exception e) {
            e.printStackTrace();
        }   
    }

//============================================================//
//  Méthode invalidate_writer: invalider un écrivain		  //
//============================================================//

    public synchronized Object invalidate_writer() {
        this.accesPossible = true;
        switch (lock) {
            case WLT:
                while (lock == Lock.WLT) {
                    try {
                        wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            case WLC:
                lock = Lock.NL;
                break;
            case RLT_WLC:
                while (lock == Lock.RLT_WLC) {
                    try {
                        wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                lock = Lock.NL;
                break;
            default:
                break;
        }

        this.accesPossible = false;
        try {
            notify();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return obj;
    }


}

